// JavaScript Document

$(document).ready(function(){
	
// World Map End spanish

// USA Map

$(".redLine").click(function(){							
	//hideMapLine();
	$(".red").toggle();
	$(this).toggleClass("redLineclicked");
});

$(".orangeLine").click(function(){
	//hideMapLine();
	$(".orange").toggle();
	$(this).toggleClass("orangeLineclicked");
});

$(".yellowLine").click(function(){
	//hideMapLine();
	$(".yellow").toggle();
	$(this).toggleClass("yellowLineclicked");
});

// USA Map spanish


$(".redLinesp").click(function(){
	//hideMapLine();
	$(".red").toggle();
	$(this).toggleClass("redLinespclicked");
});

$(".orangeLinesp").click(function(){
	//hideMapLine();
	$(".orange").toggle();
	$(this).toggleClass("orangeLinespclicked");
});

$(".yellowLinesp").click(function(){
	//hideMapLine();
	$(".yellow").toggle();
	$(this).toggleClass("yellowLinespclicked");
});

$(".viewAllLine").click(function(){
	$(".yellow").show();
	$(".red").show();
	$(".orange").show();
});

function hideMapLine(){
	$(".yellow").hide();
	$(".red").hide();
	$(".orange").hide();
}



	
	
	

});

