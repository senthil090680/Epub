var total = 1;
var questionCount = 4;
var rightAnswerCount=0;
var rightAnsCount = 0;
var wrongAnscount = 0;
var instructionTxt = new Array();


//var dadEleCount = 8;

var CountOfAnswers1 = 0;
var rightDrag1 = 0;
var wrong_count1 = 0;
var wrongDragEle1 = [];
var wrongDropEle1 =[];
var getPage;

var dragRevert = true;
var draggedItems = "";
var droppedItems = "";

var rndNum;
var optionSelected;
var feedbackContent="";
var selectionCount = 0;
var positiveFeedArray =['Great!','Good Job!','That\'s correct.'];
var negativeFeedArray =['Try again.','Try again.'];


var questArray  =['','','',''];
var answerArray =['','','',''];
var dataTxt 	=['','','','',''];

var overlayTxt = ['Correct Answers'];

dataTxt[1] ='<div class="contin"><div class="CorrectAns"></div><div class="scoreCard"></div><div class="show_boardMyAns"></div><div class="show_boardAns"></div><a href="postonfacebook"><div class="facebook"></div></a><div class="refresh"></div><div class="dragBg" id="dragBg"><div class="gadget dndQuiz" clone="true" reset="true" freedrag="true"><div class="drag" hideondrop="false"></div><div class="drop"></div></div></div><div id="submit"></div></div>';


	$(document).ready(function(){
		$(window).bind("load",function(){
					loadData(1);
					init();
		});
	});
	

function loadData(dat){
	getPage = dat;
	instruction = instructionTxt[0];
	if(dataTxt[dat] != "")
	{
		$('#page').append('<div id="pageTxt" class="txtStyle"></div>');
		$('#pageTxt').html(dataTxt[dat]);
	}
	$('.instructioncontainer').empty();
	$('.instructioncontainer').html(instruction);
	if(dat == 1)
	{

			$('.drop').append('<div class="dropItem" dropid="1" id="drop1" style="left:204px;top:92px;width:168px;height:41px;" iscorrect="false"></div>');
			$('.drop').append('<div class="dropItem" dropid="2" id="drop2" style="left:204px;top:172px;width:168px;height:41px;"  iscorrect="false"></div>');
			$('.drop').append('<div class="dropItem" dropid="1" id="drop3" style="left:730px;top:92px;width:168px;height:41px;" iscorrect="false"></div>');
			$('.drop').append('<div class="dropItem" dropid="2" id="drop4" style="left:730px;top:172px;width:168px;height:41px;" iscorrect="false"></div>');
			
			
			
			var dArray = ['1','2','3','4'];
			var dragLength = dArray.length;
			for ( var i = dArray.length - 1; i > 0; i-- ){
				var j = randint( 0, i );
				var temp = dArray[i];
				dArray[i] = dArray[j];
				dArray[j] = temp;
			}
		for ( var i = 0;i<dArray.length; i++ ){
			
			var dragidval = dArray[i];
			
			if(dragidval == 3)
				dragidval = 1;
			
			if(dragidval == 4)
				dragidval = 2;
				
			$('.drag').append('<div clone="0" class="dragItem ui-draggable" dragid="'+dragidval+'" id="drag'+dArray[i]+'" iscorrect="false" page="2"><img src="images/drag'+dArray[i]+'.png" /></div>');
		}
			
		$('.dragItem div').css({'background-color':'#ededed','text-align':'center','padding-top':'6px','width':'70px','height':'20px','border':'1px solid #acacac'});
			
		CountOfAnswers1 = 0;
		
		dragRevert = true;
		$('.drag div, .drop div div').draggable({stack: ".drag div, .drop div div" });
		$(".ui-draggable").draggable({containment:'#dragBg', revert: function(){if(dragRevert == true){return true;}else{dragRevert = true;}}});
		

		$(".drop>div").each(function(){
			$(this).droppable({
				drop:function(event, ui){
					//if($(this).html() == ""){
					var DragEleid = ui.draggable.attr("id");
					var strF = ui.draggable.attr("id");
					strF = strF.replace("drag","");
					var dID = eval(strF - 1);
					var dragId = "#" + ui.draggable.attr("id");
					
					if($(this).html() != ""){
						var tempDragArray1 = draggedItems.split(",");
						var tempDropArray1 = droppedItems.split(",");
						var	indexPos5 =  tempDragArray1.indexOf($(this).children('.dragItem').attr("id"));
						var	indexPos6 =  wrongDragEle1.indexOf($(this).children('.dragItem').attr("id"));
						
						if(indexPos5 >= 0){
							
							tempDragArray1.splice(indexPos5,1);
							tempDropArray1.splice(indexPos5,1);
							
							draggedItems = tempDragArray1.toString();
							droppedItems = tempDropArray1.toString();
						
							if(indexPos6 >= 0){
								wrongDragEle1.splice(indexPos6,1);
								wrongDropEle1.splice(indexPos6,1);
							} else if(indexPos6 >= -1) {
								rightDrag1--;
							}
						}
						
						$('.drag').append('<div clone="0" class="dragItem ui-draggable" dragid="'+$(this).children('.dragItem').attr("dragid")+'" id="drag'+$(this).children('.dragItem').attr("dragid")+'" iscorrect="false" page="2"><img src="images/drag'+$(this).children('.dragItem').attr("dragid")+'.png" /></div>');

						$('.drag>div').each(function(){
							var b=$(this).removeAttr("style");
						});
						
						dragRevert = true;
						$('.drag div, .drop div div').draggable({stack: ".drag div, .drop div div" });
						$(".ui-draggable").draggable({containment:'#dragBg', revert: function(){if(dragRevert == true){return true;}else{dragRevert = true;}}});
						
						$(this).html('');
						
					}
					
					$(this).html($(dragId));

					dragRevert = true;
					$('.drag div, .drop div div').draggable({stack: ".drag div, .drop div div" });
					$(".ui-draggable").draggable({containment:'#dragBg', revert: function(){if(dragRevert == true){return true;}else{dragRevert = true;}}});
					
					CountOfAnswers1++;
					
					if(draggedItems == ""){
						draggedItems = ui.draggable.attr("id");
						droppedItems = $(this).attr("id");
					}else{
						var tempDragArray = draggedItems.split(",");
						var tempDropArray = droppedItems.split(",");
						
						var	indexPos2 =  tempDragArray.indexOf(ui.draggable.attr("id"));
						var	indexPos4 =  wrongDragEle1.indexOf(ui.draggable.attr("id"));
						
						if(indexPos2 >= 0){
							tempDragArray.splice(indexPos2,1);
							tempDropArray.splice(indexPos2,1);
							draggedItems = tempDragArray.toString();
							droppedItems = tempDropArray.toString();
							
							if(indexPos4 >= 0){
								wrongDragEle1.splice(indexPos4,1);
								wrongDropEle1.splice(indexPos4,1);
							} else if(indexPos4 >= -1) {
								rightDrag1--;
							}
						}
						if(draggedItems == ""){
							draggedItems = ui.draggable.attr("id");
							droppedItems = $(this).attr("id");
						} else {
							draggedItems = draggedItems + "," + ui.draggable.attr("id");
							droppedItems = droppedItems + "," + $(this).attr("id");
						}
					}
					
					if(ui.draggable.attr("dragId") == $(this).attr("dropId")){
						rightDrag1++;
					}else{
						wrongDropEle1.push($(this).attr("id"));
						wrongDragEle1.push(DragEleid);
					}
					
					if($('.drag').html() == ""){
						$('#submit').show();
					}
					$(dragId).removeAttr('style');
					init();	
				}
			});
			
		});
	}
}
	

function showRightAnswers(){
	for(var i=0; i<questionCount; i++){
		$("#drop"+(i+1)).html('');
		$("#drop"+(i+1)).html('<img src="images/drag'+(i+1)+'.png" />');
	}
}

function showUserAnswers(){
	var tempDgItem = draggedItems.split(',');
	var tempDpItem = droppedItems.split(',');
	
	for(var i=1; i<=questionCount; i++){
		$("#"+tempDpItem[i]).html('');
		$("#drop"+i).html('<img src="images/drag'+i+'.png"/>');
		$("#drop"+i).append('<img class="wrong" src="images/right.png"/>');
		/*$("#"+tempDpItem[i]).html('<img src="images/'+tempDgItem[i]+'.png" />');
		if(tempDgItem[i].replace("drag","") == tempDpItem[i].replace("drop","")){
			$("#"+tempDpItem[i]).append('<img class="wrong" src="images/right.png"/>');
		} else {
			$("#"+tempDpItem[i]).append('<img class="wrong" src="images/wrong.png"/>');
		}*/
	}
	
}
function showAnswer(){
	$('.instructioncontainer').empty().html('<div class="averageTxt">You Scored : <span class="average"></span> %</div><div class="scoreText">Right Answer : <span class="score"></span></div><div class="scoreText">Wrong Answer : <span class="scoreWrong"></span></div><div id="tryagain"></div><div id="showanswers"></div>');
	$("#instructionarea").show();
	$('#submit').hide();
	$('.score').html(rightAnsCount);
	$('#score').val(rightAnsCount);
	$('.scoreWrong').html(wrongAnscount);
	$('.average').html(Math.round((rightAnsCount/questionCount)*100 - 0.01));
	$('#average').val(Math.round((rightAnsCount/questionCount)*100 - 0.01));
}

$('#submit').live('click',function(){
	for(var i=0; i<questionCount; i++){
		//alert($("#drop"+(i+1)).attr("dropid")+'->'+$("#drop"+(i+1)).children('.dragItem').attr("dragid"));
		if($("#drop"+(i+1)).attr("dropid") == $("#drop"+(i+1)).children('.dragItem').attr("dragid")){
			rightAnsCount++;
			$("#drop"+(i+1)).append('<img class="wrong" src="images/right.png"/>');
		} else {
			$("#drop"+(i+1)).append('<img class="wrong" src="images/wrong.png"/>');
		}
	}
	wrongAnscount = questionCount - rightAnsCount;
	showAnswer();
});

$('#tryagain').live('click',function(){
	location.reload();
});

$(".closebtn").live('click', function(){
	$("#instructionarea").hide();
});

$('#showanswers').live('click',function(){
	$('.CorrectAns').empty().html('');
	$("#instructionarea").hide();
	$('.scoreCard, .show_boardMyAns, .show_boardAns, .facebook, .refresh').show();
	showUserAnswers();
});

$('.scoreCard').live('click', function(){
	$("#instructionarea").show();
});

$(".show_boardAns").live('click', function(){
	$('.CorrectAns').empty().html(overlayTxt[0]);
	$("#instructionarea, .show_boardAns").hide();
	$(".show_boardMyAns").show();
	showRightAnswers();
});

$(".show_boardMyAns").live('click', function(){
	$('.CorrectAns').empty().html('');
	$("#instructionarea, .show_boardMyAns").hide();
	$(".show_boardAns").show();
	showUserAnswers();
});


$('.refresh').live('click',function(){
	location.reload();
});

// Returns an integer uniformly distributed over l..u.
function randint( l, u ){
	return l + Math.floor( Math.random() * ( u + 1 - l ));
}

function init(){
	var a=0;$(".dragItem").each(function(){
		var b=$(this).attr("id");
		var c=document.getElementById(b);
		a++;
		c.addEventListener("touchstart",touchHandler,true);
		c.addEventListener("touchmove",function(e){e.preventDefault()},true);
		c.addEventListener("touchmove",touchHandler,true);
		c.addEventListener("touchend",touchHandler,true);
		c.addEventListener("touchcancel",touchHandler,true);
	});
}
function touchHandler(a){
	var b=a.changedTouches,c=b[0],d="";
	switch(a.type){
		case"touchstart":
			d="mousedown";
			break;
		case"touchmove":
			d="mousemove";
			break;
		case"touchend":
			d="mouseup";
			break;
		default:
			return;
	}
	var e=document.createEvent("MouseEvent");
	e.initMouseEvent(d,true,true,window,1,c.screenX,c.screenY,c.clientX,c.clientY,false,false,false,false,0,null);
	c.target.dispatchEvent(e);
}