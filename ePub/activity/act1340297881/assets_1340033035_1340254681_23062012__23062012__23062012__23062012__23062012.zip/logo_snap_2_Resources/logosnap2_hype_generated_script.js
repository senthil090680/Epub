//	HYPE.documents["logo_snap_2"]

(function HYPE_DocumentLoader() {
	var resourcesFolderName = "logo_snap_2_Resources";
	var documentName = "logo_snap_2";
	var documentLoaderFilename = "logosnap2_hype_generated_script.js";

	// find the URL for this script's absolute path and set as the resourceFolderName
	try {
		var scripts = document.getElementsByTagName('script');
		for(var i = 0; i < scripts.length; i++) {
			var scriptSrc = scripts[i].src;
			if(scriptSrc != null && scriptSrc.indexOf(documentLoaderFilename) != -1) {
				resourcesFolderName = scriptSrc.substr(0, scriptSrc.lastIndexOf("/"));
				break;
			}
		}
	} catch(err) {	}

	// Legacy support
	if (typeof window.HYPE_DocumentsToLoad == "undefined") {
		window.HYPE_DocumentsToLoad = new Array();
	}
 
	// load HYPE.js if it hasn't been loaded yet
	if(typeof HYPE_100 == "undefined") {
		if(typeof window.HYPE_100_DocumentsToLoad == "undefined") {
			window.HYPE_100_DocumentsToLoad = new Array();
			window.HYPE_100_DocumentsToLoad.push(HYPE_DocumentLoader);

			var headElement = document.getElementsByTagName('head')[0];
			var scriptElement = document.createElement('script');
			scriptElement.type= 'text/javascript';
			scriptElement.src = resourcesFolderName + '/' + 'HYPE.js?hype_version=100';
			headElement.appendChild(scriptElement);
		} else {
			window.HYPE_100_DocumentsToLoad.push(HYPE_DocumentLoader);
		}
		return;
	}
	
	var hypeDoc = new HYPE_100();
	
	var attributeTransformerMapping = {b:"i",c:"i",bC:"i",aS:"i",d:"i",M:"i",e:"f",N:"i",f:"d",aT:"i",O:"i",g:"c",aU:"i",P:"i",Q:"i",aV:"i",R:"c",aW:"f",aI:"i",S:"i",T:"i",l:"d",aX:"i",aJ:"i",m:"c",n:"c",aK:"i",X:"i",aZ:"i",A:"c",Y:"i",aL:"i",B:"c",C:"c",D:"c",t:"i",E:"i",G:"c",bA:"c",a:"i",bB:"i"};

var scenes = [{timelines:{kTimelineDefaultIdentifier:{framesPerSecond:30,animations:[{t:0,p:1,i:"Video Track",d:0.16253968,o:"16",f:"2"},{f:"2",t:0.06666667,d:0.06666667,i:"e",e:"1.000000",r:1,s:"0.000000",o:"2"},{f:"2",t:0.1,d:0.06666667,i:"e",e:"1.000000",r:1,s:"0.000000",o:"3"},{f:"2",t:0.13333334,d:0.066666663,i:"e",e:"1.000000",r:1,s:"0.000000",o:"4"},{f:"2",t:0.13333334,d:0.63333333,i:"e",e:"1.000000",s:"1.000000",o:"2"},{f:"2",t:0.16666667,d:0.066666663,i:"e",e:"1.000000",r:1,s:"0.000000",o:"5"},{f:"2",t:0.16666667,d:0.56666666,i:"e",e:"1.000000",s:"1.000000",o:"3"},{f:"2",t:0.2,d:0.5,i:"e",e:"1.000000",s:"1.000000",o:"4"},{f:"2",t:0.2,d:0.066666678,i:"e",e:"1.000000",r:1,s:"0.000000",o:"6"},{f:"2",t:0.23333333,d:0.43333334,i:"a",e:73,r:1,s:73,o:"10"},{f:"2",t:0.23333333,d:0.066666678,i:"e",e:"1.000000",r:1,s:"0.000000",o:"7"},{f:"2",t:0.23333333,d:0.43333334,i:"e",e:"1.000000",s:"1.000000",o:"5"},{f:"2",t:0.26666668,d:0.36666664,i:"e",e:"1.000000",s:"1.000000",o:"6"},{f:"2",t:0.30000001,d:0.36666667,i:"b",e:-10,r:1,s:339,o:"10"},{f:"2",t:0.30000001,d:0.30000001,i:"e",e:"1.000000",s:"1.000000",o:"7"},{f:"2",t:0.60000002,d:0.033333302,i:"e",e:"0.000000",r:1,s:"1.000000",o:"8"},{f:"2",t:0.60000002,d:0.066666663,i:"e",e:"0.000000",s:"1.000000",o:"7"},{f:"2",t:0.63333333,d:0.066666663,i:"e",e:"0.000000",s:"1.000000",o:"6"},{f:"2",t:0.66666669,d:0.066666663,i:"e",e:"0.000000",s:"1.000000",o:"5"},{f:"2",t:0.66666669,d:0.23333329,i:"b",e:16,s:-10,o:"10"},{f:"2",t:0.69999999,d:0.066666663,i:"e",e:"0.000000",s:"1.000000",o:"4"},{f:"2",t:0.73333335,d:0.066666663,i:"e",e:"0.000000",s:"1.000000",o:"3"},{f:"2",t:0.76666665,d:0.066666663,i:"e",e:"0.000000",s:"1.000000",o:"2"},{f:"2",t:0.80000001,d:0.099999964,i:"aW",e:"0.200000",r:1,s:"0.200000",o:"10"},{f:"2",t:0.80000001,d:0.099999964,i:"aX",e:-60,r:1,s:-40,o:"10"},{t:0.86666667,p:1,i:"Video Track",d:0.27863947,o:"14",f:"2"},{f:"2",t:0.89999998,d:0.033333361,i:"e",e:"0.000000",r:1,s:"1.000000",o:"10"},{f:"2",t:0.89999998,d:0.066666663,i:"e",e:"1.000000",r:1,s:"0.000000",o:"11"},{f:"2",t:0.93333334,d:0.066666663,i:"e",e:"1.000000",r:1,s:"0.000000",o:"12"},{f:"2",t:0.96666664,d:0.033333361,i:"e",e:"0.000000",s:"1.000000",o:"11"},{f:"2",t:0.96666664,d:0.10000008,i:"e",e:"1.000000",r:1,s:"0.000000",o:"13"}],identifier:"kTimelineDefaultIdentifier",name:"Main Timeline",duration:1.1453061}},sceneIndex:0,perspective:"600px",oid:"1",initialValues:{"10":{o:"content-box",h:"logo_1.png",x:"visible",aW:"0.200000",q:"100% 100%",b:339,j:"absolute",r:"inline",z:"8",k:"div",aX:-40,d:320,c:675,a:73,e:"1.000000"},"2":{o:"content-box",h:"Untitled-1.png",x:"visible",a:380,q:"100% 100%",b:320,j:"absolute",r:"inline",c:39,k:"div",z:"2",d:3,e:"0.000000"},"3":{o:"content-box",h:"Untitled-2.png",x:"visible",a:349,q:"100% 100%",b:319,j:"absolute",r:"inline",c:102,k:"div",z:"3",d:5,e:"0.000000"},"11":{o:"content-box",h:"logo_2.png",x:"visible",aW:"0.200000",q:"100% 100%",b:16,j:"absolute",r:"inline",z:"10",k:"div",aX:-60,d:320,c:675,a:73,e:"0.000000"},"16":{aR:"0",x:"visible",bE:[{filename:"whoop.m4a"}],a:24,b:205,j:"absolute",c:0,k:"video",aO:"1",z:"14",d:0,e:"0.000000",aQ:"0",aH:"1"},"4":{o:"content-box",h:"Untitled-3.png",x:"visible",a:295,q:"100% 100%",b:316,j:"absolute",r:"inline",c:210,k:"div",z:"4",d:11,e:"0.000000"},"5":{o:"content-box",h:"Untitled-4.png",x:"visible",a:227,q:"100% 100%",b:313,j:"absolute",r:"inline",c:346,k:"div",z:"5",d:17,e:"0.000000"},"12":{o:"content-box",h:"logo_3.png",x:"visible",aW:"0.200000",q:"100% 100%",b:16,j:"absolute",r:"inline",z:"11",k:"div",aX:-60,d:320,c:675,a:73,e:"0.000000"},"6":{o:"content-box",h:"Untitled-5.png",x:"visible",a:161,q:"100% 100%",b:310,j:"absolute",r:"inline",c:478,k:"div",z:"6",d:24,e:"0.000000"},"13":{o:"content-box",h:"logo_4_burst.png",x:"visible",aW:"0.200000",q:"100% 100%",b:16,j:"absolute",r:"inline",z:"12",k:"div",aX:-60,d:320,c:675,a:73,e:"0.000000"},"7":{o:"content-box",h:"Untitled-6.png",x:"visible",a:73,q:"100% 100%",b:300,j:"absolute",r:"inline",c:675,k:"div",z:"7",d:34,e:"0.000000"},"8":{o:"content-box",h:"Untitled-7.png",x:"visible",a:37,q:"100% 100%",b:307,j:"absolute",r:"inline",c:748,k:"div",z:"9",d:323,e:"1.000000"},"14":{aR:"0",x:"visible",bE:[{filename:"snap_sound.m4a"}],a:394,b:256,j:"absolute",c:0,k:"video",aO:"1",z:"13",d:0,e:"0.000000",aQ:"0",aH:"1"},"9":{c:798,d:398,I:"Solid",r:"none",J:"Solid",K:"Solid",g:"#DDEEFF",L:"Solid",M:1,N:1,A:"#A0A0A0",x:"visible",j:"absolute",B:"#A0A0A0",k:"div",O:1,C:"#A0A0A0",z:"1",P:1,D:"#A0A0A0",a:0,b:0}},backgroundColor:"#FFFFFF",name:"Untitled Scene"}];


	
	var javascripts = [];


	
	var Custom = {};
	var javascriptMapping = {};
	for(var i = 0; i < javascripts.length; i++) {
		try {
			javascriptMapping[javascripts[i].identifier] = javascripts[i].name;
			eval("Custom." + javascripts[i].name + " = " + javascripts[i].source);
		} catch (e) {
			hypeDoc.log(e);
			Custom[javascripts[i].name] = (function () {});
		}
	}
	
	hypeDoc.setAttributeTransformerMapping(attributeTransformerMapping);
	hypeDoc.setScenes(scenes);
	hypeDoc.setJavascriptMapping(javascriptMapping);
	hypeDoc.Custom = Custom;
	hypeDoc.setCurrentSceneIndex(0);
	hypeDoc.setMainContentContainerID("logosnap2_hype_container");
	hypeDoc.setResourcesFolderName(resourcesFolderName);
	hypeDoc.setShowHypeBuiltWatermark(0);
	hypeDoc.setShowLoadingPage(false);
	hypeDoc.setDrawSceneBackgrounds(true);
	hypeDoc.setDocumentName(documentName);

	HYPE.documents[documentName] = hypeDoc.API;

	hypeDoc.documentLoad(this.body);
}());

